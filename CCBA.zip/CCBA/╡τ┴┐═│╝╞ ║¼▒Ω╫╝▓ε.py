import re
import statistics

def parse_file(filename):
    with open(filename, 'r', encoding='gbk') as f:
        content = f.read()

    # 查找所有 layout_result 数据块
    layout_pattern = re.compile(r'layout_result数据:\s*((?:\[\d+.*?\]\n*)+)')
    layout_matches = layout_pattern.findall(content)

    final_layout_results = []
    if layout_matches:
        # 取最后一个 layout_result 数据块
        last_layout_block = layout_matches[-1].strip()
        rows = []
        for row in re.findall(r'\[.*?\]', last_layout_block):
            try:
                data = eval(row)
                rows.append(data)
            except:
                continue
        final_layout_results.extend(rows)

    # 查找 1 次循环通信干扰决策后的 layout_result 数据
    single_loop_pattern = re.compile(r'1次循环通信干扰决策\s*layout_result数据:\s*((?:\[\d+.*?\]\n*)+)')
    single_loop_match = single_loop_pattern.search(content)
    if single_loop_match:
        single_loop_block = single_loop_match.group(1).strip()
        rows = []
        for row in re.findall(r'\[.*?\]', single_loop_block):
            try:
                data = eval(row)
                rows.append(data)
            except:
                continue
        final_layout_results.extend(rows)

    return final_layout_results

def analyze_layout_results(results):
    ground_power = []
    air_power = []

    for row in results:
        if len(row) >= 8:
            jammer_type = row[1]
            power = row[7]
            if jammer_type == 0:
                ground_power.append(power)
            elif jammer_type == 1:
                air_power.append(power)

    metrics = {}
    if ground_power:
        ground_mean = statistics.mean(ground_power)
        ground_stdev = statistics.pstdev(ground_power)
        metrics['ground_max'] = max(ground_power)
        metrics['ground_mean'] = f"{ground_mean:.2f} ± {ground_stdev:.2f}"
        metrics['ground_failure_ratio'] = ground_power.count(0) / len(ground_power)
    if air_power:
        air_mean = statistics.mean(air_power)
        air_stdev = statistics.pstdev(air_power)
        metrics['air_max'] = max(air_power)
        metrics['air_mean'] = f"{air_mean:.2f} ± {air_stdev:.2f}"
        metrics['air_failure_ratio'] = air_power.count(0) / len(air_power)

    return metrics

def main():
    filename = 'communication_interference_data.txt'
    results = parse_file(filename)

    if not results:
        print("未提取到任何 layout_result 数据")
        return

    metrics = analyze_layout_results(results)

    print("统计指标：")
    if 'ground_max' in metrics:
        print(f"地面干扰机最大值AH: {metrics['ground_max']:.2f}")
        print(f"地面干扰机均值: {metrics['ground_mean']}")
        print(f"地面干扰机失效比: {metrics['ground_failure_ratio']:.2%}")
    if 'air_max' in metrics:
        print(f"空中干扰机最大值AH: {metrics['air_max']:.2f}")
        print(f"空中干扰机均值: {metrics['air_mean']}")
        print(f"空中干扰机失效比: {metrics['air_failure_ratio']:.2%}")

if __name__ == '__main__':
    main()