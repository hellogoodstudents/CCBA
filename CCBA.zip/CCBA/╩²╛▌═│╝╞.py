import time

# 以二进制模式打开文件
with open('communication_interference_data.txt', 'rb') as file:
    binary_content = file.read()

try:
    # 尝试使用UTF-8解码
    content = binary_content.decode('utf-8')
except UnicodeDecodeError:
    try:
        # 尝试使用GBK解码
        content = binary_content.decode('GBK')
    except UnicodeDecodeError:
        # 其他编码...
        print("无法确定文件的正确编码")
        content = ""

# 初始化变量
interference_count = 0
total_runtime = 0
total_loop_value = 0
loop_count = 0
valid_list_count = 0  # 初始化符合条件的循环次数记录数量

# 按行处理文件内容
lines = content.split('\n')
for line in lines:
    if '程序运行时长:' in line:
        # 提取运行时长
        runtime = float(line.split(': ')[1].split(' ')[0])
        total_runtime += runtime
        loop_count += 1
    elif '循环通信干扰决策' in line:
        # 提取xxx次循环通信干扰决策中的数值xxx
        try:
            loop_num = int(line.split('次')[0])
            total_loop_value += loop_num
            valid_list_count += 1
            interference_count += 1
        except ValueError:
            print(f"解析循环次数时出错：{line}")

# 计算平均值
average_runtime = total_runtime / loop_count if loop_count > 0 else 0
average_loop_value = total_loop_value / valid_list_count if valid_list_count > 0 else 0
# 输出结果
interference_count = interference_count - 1
t = interference_count * 0.025



print(f"有效干扰的次数: {interference_count}")  #至少干扰1次
print(f"程序运行时长的平均值: {average_runtime:.6f} 秒")
#print(f"xxx次循环通信干扰决策中数值xxx的平均值: {average_loop_value:.2f}")
print('有效系统工作时长  总和',t,'H')



def process_comm_group(comm_lines, stats):
    """处理一组通信节点数据"""
    for line in comm_lines:
        try:
            # 安全解析列表数据
            node = eval(line)
            if len(node) >= 9:  # 确保有第8和第9列
                diff = node[7] - node[8]
                if diff > 12:
                    stats['>12'] += 1
                elif 6 < diff <= 12:
                    stats['(6,12]'] += 1
                elif 3 < diff <= 6:
                    stats['(3,6]'] += 1
                elif -1.76 < diff <= 3:
                    stats['(-1.76,3]'] += 1
                elif -4.77 < diff <= -1.76:
                    stats['(-4.77,-1.76]'] += 1
                else:
                    stats['<=-4.77'] += 1
                stats['total'] += 1
        except:
            continue

def analyze_interference_results():
    with open('communication_interference_data.txt', 'rb') as file:
        binary_content = file.read()

    try:
        content = binary_content.decode('utf-8')
    except UnicodeDecodeError:
        try:
            content = binary_content.decode('GBK')
        except UnicodeDecodeError:
            print("无法确定文件的正确编码")
            content = ""

    stats = {
        '>12': 0, '(6,12]': 0, '(3,6]': 0,
        '(-1.76,3]': 0, '(-4.77,-1.76]': 0,
        '<=-4.77': 0, 'total': 0
    }

    lines = content.split('\n')
    in_comm_section = False
    comm_lines = []

    for line in lines:
        stripped = line.strip()
        if stripped.startswith('chenggong:'):
            in_comm_section = True
            comm_lines = []
        elif in_comm_section:
            if stripped.startswith('[') and stripped.endswith(']'):
                comm_lines.append(stripped)
            elif comm_lines:  # 非数据行且已有数据，表示组结束
                process_comm_group(comm_lines, stats)
                in_comm_section = False

    # 处理最后一组可能未处理的数据
    if comm_lines:
        process_comm_group(comm_lines, stats)

    # 计算百分比
    if stats['total'] > 0:
        print("\n干扰效果统计结果:")
        print("="*40)
        print(f"差值 > 12dB: {stats['>12']}次, 占比 {stats['>12']/stats['total']*100:.2f}%")
        print(f"差值 6~12dB: {stats['(6,12]']}次, 占比 {stats['(6,12]']/stats['total']*100:.2f}%")
        print(f"差值 3~6dB: {stats['(3,6]']}次, 占比 {stats['(3,6]']/stats['total']*100:.2f}%")
        print(f"差值 -1.76~3dB: {stats['(-1.76,3]']}次, 占比 {stats['(-1.76,3]']/stats['total']*100:.2f}%")
        print(f"差值 -4.77~-1.76dB: {stats['(-4.77,-1.76]']}次, 占比 {stats['(-4.77,-1.76]']/stats['total']*100:.2f}%")
        print(f"差值 <= -4.77dB: {stats['<=-4.77']}次, 占比 {stats['<=-4.77']/stats['total']*100:.2f}%")
        print("="*40)
        print(f"总统计节点数: {stats['total']}")
    else:
        print("未找到有效数据")


if __name__ == "__main__":

    # 新增干扰效果统计
    analyze_interference_results()